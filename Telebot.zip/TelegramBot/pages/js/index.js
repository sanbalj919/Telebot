document.addEventListener('deviceready', function(){
    StatusBar.hide();
}, false);

document.getElementById("loginBtn").addEventListener("click", function(){

    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;


    /*$.ajax({
        url: "http://localhost:3000/enbdAccountAuth?username=" + username + "&password=" + password,
        type: "GET",
        success: function(data){
            window.alert("Response Received")
            localStorage.setItem("username", username);
            localStorage.setItem("password", password);
            localStorage.setItem("accountNumber", data[0].accountNumber);
            localStorage.setItem("mobileNumber", data[0].mobileNumber);
            localStorage.setItem("balance", data[0].balance);

            document.getElementById("balanceDisplay").innerHTML = data[0].balance + " AED";
            document.getElementById("nameDisplay").innerHTML = data[0].name;
            document.getElementById("accountNumberDisplay").innerHTML = data[0].accountNumber;
            document.getElementById("mobileNumberDisplay").innerHTML = data[0].mobileNumber;
*/
            /*document.getElementById("balanceDisplay").innerHTML = "10000 AED";
            document.getElementById("nameDisplay").innerHTML = "Santhosh";
            document.getElementById("accountNumberDisplay").innerHTML = "1015002100021";
            document.getElementById("mobileNumberDisplay").innerHTML = "0554933123";*/

            document.getElementById("loginPage").style.display = "none";
            document.getElementById("appPage").style.display = "block";
            //document.getElementById("balancePage").style.display = "block";
            document.getElementById("transactionsPage").style.display = "block";
        /*},
        error: function(){
            navigator.notification.alert(
                'Please check the username and password',  // message
                null,         // callback
                'Invalid',            // title
                'Try Again'                  // buttonName
            );
        }
    });*/
}, false);

function sendSMS(element) {
    var triggeredId = element.id;
    
    if(document.getElementById(triggeredId).innerHTML === 'Initiate') {
        document.getElementById(triggeredId).innerHTML = 'Initiated';
        //alert('SMS Sent: '+document.getElementById(triggeredId).innerHTML);
    }
    else {
        //document.getElementById(triggeredId).innerHTML = 'Initiated';
        //Do the AJAX call here to get Downloaded link  
        $.ajax({
                        url: "http://localhost:7007/getDocumentsList",
                        type: "GET",
                        dataType: "text",
                        accepts: "text/plain",
                        success: function(data){
                            console.log('Data Received from SANTY server:'+data);
                            document.getElementById(triggeredId).innerHTML = 'Completed';
                        },
                        error: function(err){
                            document.getElementById(triggeredId).innerHTML = 'Failed';
                            alert('Error Response: '+JSON.stringify(err));
                        }
                    }) 
    }
    
}

(function(){
                    var name = 'Aswin';
                    var cifid = '50125789';
                    var mobile = '0541893648';
                    var media = 'Telegram';
                    var pendingDoc = 'Passport';
                    var action = 'Completed';
                    var filePath = 'https://api.telegram.org/file/bot576925049:AAHrzLIRFFZFd-tU8IPxElcaTjazCGcVy8c/documents/file_3.JPG';
                    var initiateBtnCount = 0;
                    initiateBtnCount++;
                    var buttonId = "initiateBtn"+initiateBtnCount;
                
                    document.getElementById("documentsList").innerHTML = `
                                                <tr>
                                                    <td>${name}</td>
                                                    <td>${cifid}</td>
                                                    <td>${mobile}</td>
                                                    <td>${media}</td>
                                                    <td>${pendingDoc}</td>
                                                    <td><button id="${buttonId}" class="btn btn-default btn-flat">${action}</button></td>
                                                    <td>
                                                        <a href="${filePath}" class="btn btn-default btn-flat">Download</a>
                                                    </td>
                                                </tr>
                    ` + document.getElementById("documentsList").innerHTML;
                })();