var express = require('express');
var app = express();
var bodyParser = require('body-parser');
const axios = require('axios')
const fs = require('fs');
const url = require("url");


app.use(express.static('pages'));

app.use(bodyParser.json()); // for parsing application/json
app.use(bodyParser.urlencoded({
  extended: true
})); // for parsing application/x-www-form-urlencoded

app.get('/',function(req,res){ 
  console.log("SANTY BOT: NOT API Request - Normal GET Req");
  res.sendFile(__dirname+'/pages/index.html');
});

app.get('/getDocumentsList',function(req,res){ 
  console.log("SANTY BOT: API Call to getDocumentsList")

  //var docs = {"mobile":"0553042345","cifid":"12345678"};
  var docs = 'Completed';
  console.log("About to response 200 OK");

  //res.status(200);
  res.send(JSON.stringify(docs));
});

//This is the route the API will call
app.post('/new-message', function(req, res) {
  const {message} = req.body

  console.log("SANTY BOT -- JSON Stringified Request::"+JSON.stringify(message));
  
  //if (!message || message.text.toLowerCase().indexOf('santi') <0) {
  if (!message) {
    console.log("SANTY BOT - NO MESSAGE");
    return res.end()
  }

  console.log("SANTY BOT - MESSAGE RECEIVED");

  if(typeof message.text!=="undefined") {     
    
    console.log("SANTY BOT - Message in LOWER CASE:"+message.text.toLowerCase());
    console.log("SANTY BOT - Santi found @:"+message.text.toLowerCase().indexOf('santi'));

    if (message.text.toLowerCase().indexOf('santi') !== -1 || message.text.toLowerCase().indexOf('/start') !== -1) {
      console.log("SANTY BOT:"+message.text);
      //Extract as a function
      axios.post('https://api.telegram.org/bot576925049:AAHrzLIRFFZFd-tU8IPxElcaTjazCGcVy8c/sendMessage', {
        chat_id: message.chat.id,
        text: 'Dear Customer, I can help you with uploading documents to ENBD. To start, please verify your mobile number by tapping on below button!',
        reply_markup: JSON.stringify({keyboard: [[{ text: "Click to verify your mobile number", request_contact: true, }]], one_time_keyboard: true})
      })
        .then(response => {
          console.log('Message posted')
          res.end('ok')
        })  
        .catch(err => {
          console.log('Error :', err)
          res.end('Error :' + err)
        })
    }
    else {
      console.log("SANTY BOT:"+message.text);
      //Extract as a function
      axios.post('https://api.telegram.org/bot576925049:AAHrzLIRFFZFd-tU8IPxElcaTjazCGcVy8c/sendMessage', {
        chat_id: message.chat.id,
        text: 'I can help you with uploading documents to ENBD. But if there is anything else, I can help you find the right bot'
      })
        .then(response => {
          console.log('Message posted')
          res.end('ok')
        })  
        .catch(err => {
          console.log('Error :', err)
          res.end('Error :' + err)
        })
    }
  }
  else if(typeof message.contact!=="undefined") {
    console.log("SANTY BOT - ***CONTACT received****");
    let mobilenumber = message.contact.phone_number;
    console.log("SANTY BOT - Mobile number:"+mobilenumber);

    axios.post('https://api.telegram.org/bot576925049:AAHrzLIRFFZFd-tU8IPxElcaTjazCGcVy8c/sendMessage', {
        chat_id: message.chat.id,
        text: 'Good, please upload a copy of your new passport'
      })
        .then(response => {
          console.log('Message posted')
          res.end('ok')
        })  
        .catch(err => {
          console.log('Error :', err)
          res.end('Error :' + err)
        })

  }

  console.log("SANTY BOT: Checking if any doc uploaded....");

  if (typeof message.document!=="undefined") {
    console.log("SANTY BOT - ***File or document received****");
    console.log("SANTY BOT - Document's Metadata Received:"+JSON.stringify(message.document));
    console.log("SANTY BOT - File ID of uploaded File:"+message.document.file_id);

    let url = 'https://api.telegram.org/bot576925049:AAHrzLIRFFZFd-tU8IPxElcaTjazCGcVy8c/getFile?file_id='+message.document.file_id;
    console.log("SANTY BOT - URL to getFile's Path:"+url);

    //Extract as a function
    axios.post('https://api.telegram.org/bot576925049:AAHrzLIRFFZFd-tU8IPxElcaTjazCGcVy8c/sendMessage', {
        chat_id: message.chat.id,
        text: 'Thank you for uploading your passport. It is getting verified..Please hold on!'
      })
        .then(response => {
          console.log('Message posted')
          res.end('ok')
        })  
        .catch(err => {
          console.log('Error :', err)
          res.end('Error :' + err)
        })

    axios.get(url)
      .then(response => {
        console.log('Get REquest to GetFilePath SUCCESS!!');
        console.log('Response from GEtFile:'+JSON.stringify(response.data));
        console.log('Type of Response.data::'+typeof response.data);
        let filePath = '';
        if(typeof response.data.result !=="undefined") {
          filePath = response.data.result.file_path;
        }
        else if (typeof response.data.file_path !=="undefined") {
          filePath = response.data.file_path;
        }
        else {
          filePath = 'documents/file_7.JPG';
        }
        
        let fileURL = 'https://api.telegram.org/file/bot576925049:AAHrzLIRFFZFd-tU8IPxElcaTjazCGcVy8c/'+filePath;
        axios.get(fileURL, {responseType: 'stream'})
          .then(response => {
            console.log('File Downloaded from obtianed file path');
            let fileName = 'Passport_'+message.chat.id+'.jpeg';
            console.log('File name constructed:'+fileName);
            // console.log('***FILE CONTENT****::'+response.data);
            response.data.pipe(fs.createWriteStream(fileName));
            console.log('File Downloaded successfuly @:'+fileName);
          })
          .catch(err => {
            console.log('Error :', err)
            res.end('Error :' + err)
          })
        res.end('ok')
      })
      .catch(err => {
          console.log('Error :', err)
          res.end('Error :' + err)
      })
  }

  });

app.listen(7007, function() {
  console.log('Telegram app listening on port 7007!');
});