var express = require('express');
var app = express();
var bodyParser = require('body-parser');
const axios = require('axios')
const fs = require('fs');
const url = require("url");

var MongoClient = require('mongodb').MongoClient;
var kyclist = null;
var db = null;
var mongo_url = "mongodb://telemongodb:PknG4jZ5iozd4Zx50YU4e1vK0gYIBsLyNuil1Vi3HEqb1YKimZQirv0SbUMBbeuhBdp3A5AUVtrQ1KjSmC2CsA%3D%3D@telemongodb.documents.azure.com:10255/?ssl=true&replicaSet=globaldb";
//var mongo_url = 'mongodb://localhost:27017/payments';
MongoClient.connect(mongo_url, function (err, database) {
    console.log('Database connected:'+database)
    db = database.db('payments')
    kyclist = db.collection('kyclist');
});

app.use(express.static('pages'));

app.use(bodyParser.json()); // for parsing application/json
app.use(bodyParser.urlencoded({
  extended: true
})); // for parsing application/x-www-form-urlencoded

app.get('/',function(req,res){ 
  console.log("SANTY BOT: NOT API Request - Normal GET Req");
  res.sendFile(__dirname+'/pages/index.html');
});

app.get('/dummy', function(req,res) {
  console.log('Chat2Brand Testing')
  res.send("Reseponse from MY_BOT")
});

app.post('/wa-message', function(req,res) {
  console.log('Chat2Brand:: Webhook RECEIVED Message from WhatsApp transport')
  console.log(JSON.stringify(req.body))
  var message = req.body
  var text = message.text
  var clientId = message.client_id
  var en = 'en'
  var session_id = '123456'

  var dialogFlowURL = "https://api.dialogflow.com/v1/query";

  let data = JSON.stringify({
                      lang: en,
                      query: text,
                      sessionId: session_id
                    })

  axios.post(dialogFlowURL, data, {
      headers: { "Content-Type":"application/json", "Authorization":"Bearer 2a745c0a38ad40128518897038ebbbfd" }
      })
      .then(response => {
        console.log('Response from Dialog Flow HR Bot:'+JSON.stringify(response.data))
        let dfSpeech = response.data.result.speech
        postC2BMessage(clientId,dfSpeech,'whatsapp',res)
      })  
      .catch(err => {
        console.log('Error :', err)
      })
  res.send("BOT Got your message!")
});

app.post('/ibwa-message', function(req,res) {
  console.log('Infobip:: Webhook RECEIVED Message from Infobip API')
  console.log(JSON.stringify(req.body))
});

app.get('/getDocumentsList',function(req,res){ 
  console.log("SANTY BOT: API Call to getDocumentsList")

  var url_parts = url.parse(req.url, true);
  var query = url_parts.query;

  var cifid = query.cifid;
  console.log('Mobile number from Request:'+cifid);

  var data = 'Completed';
  console.log("About to response 200 OK");

  res.send(data);
});

app.get('/getAllDocumentsList',function(req,res){ 
  console.log("SANTY BOT: API Call to getDocumentsList")

  db.collection('kyclist').find().toArray(function(err, docs){
    if(err)
    {
      res.status(400).send('Error');
    }
    else
    {
      console.log('Mongo DB call response:'+JSON.stringify(docs))
      res.send(docs);
    }
  })
  console.log("Responded 200 OK");
});

app.post('/new-message', function(req, res) {
  const {message} = req.body

  console.log("SANTY BOT -- JSON Stringified Request::"+JSON.stringify(message));
  
  if (!message) {
    console.log("SANTY BOT - NO MESSAGE");
    return res.end()
  }

  console.log("SANTY BOT - MESSAGE RECEIVED");

  if(typeof message.text!=="undefined") {     
    
    console.log("SANTY BOT - Message in LOWER CASE:"+message.text.toLowerCase());
    var mtext = message.text;

    if (mtext.toLowerCase().indexOf('hello') !== -1 || mtext.toLowerCase().indexOf('/start') !== -1 || mtext.toLowerCase().indexOf('hi') !== -1) {
      var dltoken = null;
      var customerName = "";
      if(mtext.toLowerCase().indexOf('/start') !== -1 ) {
          let splitText = mtext.split(" ",2)
          dltoken = splitText[1]
          console.log('DL Token from chat user:'+dltoken)

          if(dltoken !== 'undefined') {
            if(db === null) {
              MongoClient.connect(mongo_url, function (err, database) {
                console.log('Database connected:'+database)
                db = database.db('payments')
                db.collection('kyclist').updateOne({"dltoken" : dltoken},
                {
                  $set: { "chatid": message.chat.id},
                }, function(err, results) {
                  console.log(results);
                })
              });
            }  
          }              
      }

      MongoClient.connect(mongo_url, function (err, database) {
        console.log('Database connected:'+database)
        db = database.db('payments')
        db.collection('kyclist').findOne({'chatid':message.chat.id}, function(err, docs){
        if(err)
        {
          console.log("Error in checking DL Token in Mongo")
        }
        else
        {
          //console.log("Response from Mongo for DL token:"+docs)
          customerName = docs.name;
          console.log('Customer Name:'+customerName)
          axios.post('https://api.telegram.org/bot576925049:AAHrzLIRFFZFd-tU8IPxElcaTjazCGcVy8c/sendMessage', {
              chat_id: message.chat.id,
              text: 'Dear '+customerName+', I can help you with completing the KYC process by uploading the pending documents to the bank from here. To start with, please verify your mobile number by tapping on below button!',
              reply_markup: JSON.stringify({keyboard: [[{ text: "Click to verify your mobile number", request_contact: true, }]], one_time_keyboard: true})
          })
            .then(response => {
              console.log('Message posted')
              res.end('ok')
            })  
            .catch(err => {
              console.log('Error :', err)
              res.end('Error :' + err)
            })
          }
        })
      });

         
    }
    else {
      console.log("SANTY BOT:"+message.text);
      var stext;
      if (mtext.toLowerCase().indexOf('passport') !== -1 || mtext.toLowerCase().indexOf('emiratesid') !== -1 || mtext.toLowerCase().indexOf('visa') !== -1 || mtext.toLowerCase().indexOf('fatca') !== -1) {
        stext = "Please proceed with uploading front and back copy of your "+mtext; 
      }
      else {
        stext = "Sorry I did not understand your query or selection. I can help you with uploading documents to ENBD. But if there is anything else, please check with this guy @ENBDFatherBot";
      }
      //Extract as a function
      axios.post('https://api.telegram.org/bot576925049:AAHrzLIRFFZFd-tU8IPxElcaTjazCGcVy8c/sendMessage', {
        chat_id: message.chat.id,
        text: stext
      })
        .then(response => {
          console.log('Message posted')
          res.end('ok')
        })  
        .catch(err => {
          console.log('Error :', err)
          res.end('Error :' + err)
        })
    }
  }
  else if(typeof message.contact!=="undefined") {
    console.log("SANTY BOT - ***CONTACT received****");
    let mobilenumber = message.contact.phone_number;
    var registeredMobile;
    console.log("SANTY BOT - Mobile number:"+mobilenumber);

    db.collection('kyclist').findOne({'chatid':message.chat.id}, function(err, docs){
      if(err)
      {
        console.log("Error in checking DL Token in Mongo")
      }
      else
      {
        registeredMobile = docs.mobile;
        console.log('Customer Name:'+registeredMobile);
        if(registeredMobile === mobilenumber) {
            axios.post('https://api.telegram.org/bot576925049:AAHrzLIRFFZFd-tU8IPxElcaTjazCGcVy8c/sendMessage', {
                chat_id: message.chat.id,
                text: 'Good, looks like you have not yet submitted the below documents. Please select which one would you like to start with',
                reply_markup: JSON.stringify({keyboard: [[{text: "Passport"},{text: "EmiratesID"}],[{text: "VISA"},{text: "FATCA"}]], one_time_keyboard: true})
            })
            .then(response => {
                console.log('Message posted')
                res.end('ok')
            })  
            .catch(err => {
                console.log('Error :', err)
                res.end('Error :' + err)
            })
        }
        else {
            axios.post('https://api.telegram.org/bot576925049:AAHrzLIRFFZFd-tU8IPxElcaTjazCGcVy8c/sendMessage', {
                chat_id: message.chat.id,
                text: 'Looks like this is not your registered mobile number with us. So we are sorry that you will not able to proceed further from here'
            })
            .then(response => {
                console.log('Message posted')
                res.end('ok')
            })  
            .catch(err => {
                console.log('Error :', err)
                res.end('Error :' + err)
            })
        }
      }
    });     
  }

  console.log("SANTY BOT: Checking if any doc uploaded....");

  if (typeof message.document!=="undefined" || typeof message.photo!=="undefined") {
    console.log("SANTY BOT - ***Photo or document received****");
    var fileId;
    if(typeof message.document!=="undefined") {
        console.log("SANTY BOT - Document's Metadata Received:"+JSON.stringify(message.document));
        fileId = message.document.file_id;
    }
    else {
        console.log("SANTY BOT - Photo's Metadata Received:"+JSON.stringify(message.photo));
        fileId = message.photo[2].file_id;
    }
    console.log("SANTY BOT - File ID of uploaded File:"+fileId);

    let url = 'https://api.telegram.org/bot576925049:AAHrzLIRFFZFd-tU8IPxElcaTjazCGcVy8c/getFile?file_id='+fileId;
    console.log("SANTY BOT - URL to getFile's Path:"+url);
    let isSelfie = false;

    //Extract as a function
    db.collection('kyclist').findOne({'chatid':message.chat.id}, function(err, docs){
        if(err)
        {
          console.log("Error in checking DL Token in Mongo")
        }
        else
        {
          status = docs.status
          selfieInitiated = docs.selfieInitiated
          if(selfieInitiated === "YES") {
            isSelfie = true;
          }
          else {
            isSelfie = false;
          }
        }
    })

    /*axios.post('https://api.telegram.org/bot576925049:AAHrzLIRFFZFd-tU8IPxElcaTjazCGcVy8c/sendMessage', {
        chat_id: message.chat.id,
        text: 'Cool, let us upload the next document'
      })
        .then(response => {
          console.log('Message posted')
          res.end('ok')
        })  
        .catch(err => {
          console.log('Error :', err)
          res.end('Error :' + err)
        })*/

    axios.get(url)
      .then(response => {
        console.log('Get REquest to GetFilePath SUCCESS!!');
        console.log('Response from GEtFile:'+JSON.stringify(response.data));
        console.log('Type of Response.data::'+typeof response.data);
        let filePath = '';
        if(typeof response.data.result !=="undefined") {
          filePath = response.data.result.file_path;
        }
        else if (typeof response.data.file_path !=="undefined") {
          filePath = response.data.file_path;
        }
        else {
          filePath = 'documents/file_7.JPG';
        }
        
        let fileURL = 'https://api.telegram.org/file/bot576925049:AAHrzLIRFFZFd-tU8IPxElcaTjazCGcVy8c/'+filePath;

        detectFace(fileURL,message.chat.id,isSelfie);

        let kycStatus = isSelfie ? "COMPLETED" : "UPLOADED"
        console.log("---------------KYC Status::"+kycStatus)

        if(!isSelfie) {
          db.collection('kyclist').updateOne({"chatid" : message.chat.id},
          {
            $set: { "fileurl": fileURL},
          }, function(err, results) {
              if(err) {
              console.log('UPDATEERROR!!!!! to Mongo DB'+err)
            }
            else {
             console.log("FILE URL Updated successfuly")
            }
          });  
        }

        db.collection('kyclist').updateOne({"chatid" : message.chat.id},
        {
          $set: { "status": kycStatus},
        }, function(err, results) {
           if(err) {
            console.log('UPDATEERROR!!!!! to Mongo DB'+err)
          }
          else {
            db.collection('kyclist').findOne({'chatid':message.chat.id}, function(err, docs){
              if(err)
              {
                  console.log("Error in checking DL Token in Mongo")
              }
              else
              {
                let finStatus = docs.status
                console.log("---------------DOCS Status::"+status)
                if(finStatus === "UPLOADED") {
                  postMessage("Almost there! let's take a selfie to verify who is uploading",message.chat.id,res)
                  updateSelfieStatus("YES",message.chat.id)
                }
                else if(finStatus === "COMPLETED") {
                  //postMessage("Cool, let us upload the next document",message.chat.id,res) 
                  db.collection('kyclist').findOne({'chatid':message.chat.id}, function(err, docs){
                  if(err)
                  {
                    console.log("Error in checking DL Token in Mongo")
                  }
                  else
                  {
                    if(docs.selfieFaceId !== "") {
                      verifyFaceAndCompleteKYC(message.chat.id,res)
                    }
                    else
                    {
                      sleep(500).then(() => {
                        verifyFaceAndCompleteKYC(message.chat.id,res)
                      });
                   } 
                  }
                })
                  
                }
                else {
                  postMessage("Cool, let us upload the next document",message.chat.id,res) 
                }
              }
            })
          }
        });
        
        axios.get(fileURL, {responseType: 'stream'})
          .then(response => {
            console.log('File Downloaded from obtianed file path');
            let fileName = 'Passport_TG_'+message.chat.id+'.jpeg';
            console.log('File name constructed:'+fileName);
            // console.log('***FILE CONTENT****::'+response.data);
            response.data.pipe(fs.createWriteStream(fileName));
            console.log('File Downloaded successfuly @:'+fileName);
          })
          .catch(err => {
            console.log('Error :', err)
            res.end('Error :' + err)
          })
        res.end('ok')
      })
      .catch(err => {
          console.log('Error :', err)
          res.end('Error :' + err)
      })
  }

  });

var port = process.env.PORT || 7007;

app.listen(port, function() {
  console.log('Telegram app listening on port '+port);
});

function postMessage(message, chatid,res) {
  axios.post('https://api.telegram.org/bot576925049:AAHrzLIRFFZFd-tU8IPxElcaTjazCGcVy8c/sendMessage', {
        chat_id: chatid,
        text: message
      })
        .then(response => {
          console.log('Message posted')
          res.end('ok')
        })  
        .catch(err => {
          console.log('Error :', err)
          res.end('Error :' + err)
        })
}

function detectFace(sourceImageUrl,chatid, isSelfie) {
        
        var subscriptionKey = "e442cdfd339f46c895e3f72fce46c5c8";
        var uriBase = "https://northeurope.api.cognitive.microsoft.com/face/v1.0/detect";

        var params = {
            "returnFaceId": "true",
            "returnFaceLandmarks": "false",
            "returnFaceAttributes": "age,gender,headPose,smile,facialHair,glasses,emotion,hair,makeup,occlusion,accessories,blur,exposure,noise",
        };

        let data = JSON.stringify({
                      url: sourceImageUrl
                    })

        axios.post(uriBase, data, {
          headers: { "Content-Type":"application/json", "Ocp-Apim-Subscription-Key":"1e4d1fb44fc24ba392aef5fa4e5fcd9d" }
        })
        .then(response => {
          console.log('Response from Face API'+JSON.stringify(response.data));
          let faceid = response.data[0].faceId;
          console.log("SANTY BOT: FAce ID from Document:"+faceid);
          if(isSelfie) {
            updateSelfieFaceId(faceid,chatid)
          }   
          else {
            updateDocFaceId(faceid,chatid)
          }
        })  
        .catch(err => {
          console.log('Error :', err)
        })
    };

  function verifyFaceAndCompleteKYC(chatid, res) {

    var subscriptionKey = "e442cdfd339f46c895e3f72fce46c5c8";
    var uriBase = "https://northeurope.api.cognitive.microsoft.com/face/v1.0/verify";

    db.collection('kyclist').findOne({'chatid':chatid}, function(err, docs){
        if(err)
        {
          console.log("Error in checking DL Token in Mongo")
        }
        else
        {
          let docFaceId = docs.docFaceId;
          let selfieFaceId = docs.selfieFaceId;
          let isIdentical;
          let confidence;

          let data = JSON.stringify({
                      faceId1: docFaceId,
                      faceId2: selfieFaceId
                    })

          axios.post(uriBase, data, {
            headers: { "Content-Type":"application/json", "Ocp-Apim-Subscription-Key":"1e4d1fb44fc24ba392aef5fa4e5fcd9d" }
          })
          .then(response => {
            console.log('Response from Verify FACE API'+JSON.stringify(response.data));
            isIdentical = response.data.isIdentical
            confidence = response.data.confidence
            console.log("SANTY BOT: isIdentical "+isIdentical+" confidence "+confidence);
            let message = isIdentical ? "Great, we have successfuly completed the process and we will get back to you if required. Thank you for your cooperation" : "We could not verify your face on the ID, looks like it is someone else uploading the docs"
            postMessage(message,chatid,res);
          })  
          .catch(err => {
            console.log('Error :', err)
          })
        }
      });
  }

  function updateDocFaceId(faceid, chatid) {
    db.collection('kyclist').updateOne({"chatid" : chatid},
          {
            $set: {"docFaceId": faceid},
          }, function(err, results) {
            if(err) {
              console.log('UPDATEERROR!!!!! to Mongo DB'+err)
            }
            else {
              console.log(results);
            }
          });
  }

  function updateSelfieStatus(selfieInitiated, chatid) {
    db.collection('kyclist').updateOne({"chatid" : chatid},
          {
            $set: {"selfieInitiated": "YES"},
          }, function(err, results) {
            if(err) {
              console.log('UPDATEERROR!!!!! to Mongo DB'+err)
            }
            else {
              console.log(results);
            }
          });
  }

  function updateSelfieFaceId(faceid, chatid) {
    db.collection('kyclist').updateOne({"chatid" : chatid},
          {
            $set: {"selfieFaceId": faceid},
          }, function(err, results) {
            if(err) {
              console.log('UPDATEERROR!!!!! to Mongo DB'+err)
            }
            else {
              console.log(results);
            }
          });
  }

  function postC2BMessage(clientId, message, wtransport,res) {
    var c2bURL = "https://api.chat2brand.co.za/v1/messages";

    let data = JSON.stringify({
                      client_id: clientId,
                      text: message,
                      transport: wtransport
                    })

    axios.post(c2bURL, data, {
      headers: { "Content-Type":"application/json;charset=UTF-8", "Authorization":"feb4182dcdb61c41f4c2db59ad2d6c", "Accept-Encoding":"application/json" }
      })
      .then(response => {
        console.log('WA Message posted')
        res.end('ok')
      })  
      .catch(err => {
        console.log('Error :', err)
      })
  }

  // sleep time expects milliseconds
function sleep (time) {
  return new Promise((resolve) => setTimeout(resolve, time));
}




  