document.addEventListener('deviceready', function(){
    StatusBar.hide();
}, false);

document.getElementById("loginBtn").addEventListener("click", function(){

    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;


    /*$.ajax({
        url: "http://localhost:3000/enbdAccountAuth?username=" + username + "&password=" + password,
        type: "GET",
        success: function(data){
            window.alert("Response Received")
            localStorage.setItem("username", username);
            localStorage.setItem("password", password);
            localStorage.setItem("accountNumber", data[0].accountNumber);
            localStorage.setItem("mobileNumber", data[0].mobileNumber);
            localStorage.setItem("balance", data[0].balance);

            document.getElementById("balanceDisplay").innerHTML = data[0].balance + " AED";
            document.getElementById("nameDisplay").innerHTML = data[0].name;
            document.getElementById("accountNumberDisplay").innerHTML = data[0].accountNumber;
            document.getElementById("mobileNumberDisplay").innerHTML = data[0].mobileNumber;
*/
            /*document.getElementById("balanceDisplay").innerHTML = "10000 AED";
            document.getElementById("nameDisplay").innerHTML = "Santhosh";
            document.getElementById("accountNumberDisplay").innerHTML = "1015002100021";
            document.getElementById("mobileNumberDisplay").innerHTML = "0554933123";*/

            document.getElementById("loginPage").style.display = "none";
            document.getElementById("appPage").style.display = "block";
            //document.getElementById("balancePage").style.display = "block";
            document.getElementById("transactionsPage").style.display = "block";
        /*},
        error: function(){
            navigator.notification.alert(
                'Please check the username and password',  // message
                null,         // callback
                'Invalid',            // title
                'Try Again'                  // buttonName
            );
        }
    });*/
}, false);

function sendSMS(element, cifId) {
    var triggeredId = element.id;
    
    if(document.getElementById(triggeredId).innerHTML === 'Initiate') {
        document.getElementById(triggeredId).innerHTML = 'Initiated';
        //alert('SMS Sent: '+document.getElementById(triggeredId).innerHTML);
    }
    else if(document.getElementById(triggeredId).innerHTML === 'Initiated') {
        //document.getElementById(triggeredId).innerHTML = 'Initiated';
        //Do the AJAX call here to get Downloaded link  
        var cifid = document.getElementById(cifId).innerHTML;
        document.getElementById(triggeredId).innerHTML = 'Completed';
       /* $.ajax({
                        //url: "http://telebotnodejs.azurewebsites.net/getDocumentsList",
                        url: "http://localhost:7007/getDocumentsList?cifid="+cifid,
                        type: "GET",
                        accepts: "application/json",
                        success: function(data){
                            console.log('Data Received from SANTY server:'+data);
                            document.getElementById(triggeredId).innerHTML = 'Completed';
                        },
                        error: function(err){
                            document.getElementById(triggeredId).innerHTML = 'Failed';
                            alert('Error Response: '+JSON.stringify(err));
                        }
                    })*/
    
    }
    
}

(function(){
                   /* var name = '';
                    var cifid = '50125789';
                    var mobile = '0541893648';
                    var media = 'Telegram';
                    var pendingDoc = 'Passport';
                    var action = 'Completed';
                    var filePath = 'https://api.telegram.org/file/bot576925049:AAHrzLIRFFZFd-tU8IPxElcaTjazCGcVy8c/documents/file_3.JPG';*/
                    var buttonCount = 0;
                    buttonCount++;
                    var buttonId;
                    var cifid;
                    var display;

                    $.ajax({
                        url: "http://telebotnodejs.azurewebsites.net/getAllDocumentsList",
                        //url: "http://localhost:7007/getAllDocumentsList",
                        type: "GET",
                        accepts: "application/json",
                        success: function(data){
                            console.log('Data Received from SANTY server:'+data);
                            
                            for(var i=0; i<data.length; i++) {
                                buttonCount++;
                                buttonId = "initiateBtn"+buttonCount;
                                cifid = "cif"+buttonCount;
                                if(data[i].fileurl==='') {
                                    filePath = '#';
                                    display = 'none';
                                }
                                else {
                                    filePath = data[i].fileurl;
                                    display = 'block';
                                }
                                document.getElementById("documentsList").innerHTML = `
                                                <tr>
                                                    <td>${data[i].name}</td>
                                                    <td id="${cifid}">${data[i].cifid}</td>
                                                    <td>${data[i].mobile}</td>
                                                    <td>${data[i].media}</td>
                                                    <td>${data[i].doclist}</td>
                                                    <td>
                                                        <button id="${buttonId}" class="btn btn-default btn-flat" onclick="sendSMS(this, '${cifid}')">${data[i].Status}</button></td>
                                                    <td>
                                                        <a href="${filePath}" class="btn btn-default btn-flat" style="display:${display}">Download</a>
                                                    </td>
                                                </tr>
                                                ` + document.getElementById("documentsList").innerHTML;
                            }
                            
                        },
                        error: function(err){
                            console.log('Error Received from SANTY server:'+data);
                        }
                    })
                })();